﻿namespace RSC.Models
{
    public class Event
    {
        public int EventId { get; set; }

        public DateTime date { get; set; }

        public string location { get; set; }

        public string description { get; set; }

    }
}
