using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Frontpage
{
    public class FrontpageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
