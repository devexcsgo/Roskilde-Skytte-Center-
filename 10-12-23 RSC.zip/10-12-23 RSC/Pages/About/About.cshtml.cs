using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.About
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
