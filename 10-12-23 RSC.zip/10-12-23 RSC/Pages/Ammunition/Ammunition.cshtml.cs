using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Ammunition
{
    public class AmmunitionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
