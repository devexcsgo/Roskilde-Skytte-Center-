﻿using Microsoft.Extensions.Logging;
using RSC.Models;
using System.Text.Json;

namespace RSC.wwwroot.Services
{
    public class JsonFileEventService
    {
        public IWebHostEnvironment WebHostEnvironment { get; }

        public JsonFileEventService(IWebHostEnvironment webHostEnvironment)
        {
            WebHostEnvironment = webHostEnvironment;
        }
        private string JsonFileName
        {
            get { return Path.Combine(WebHostEnvironment.WebRootPath, "Data", "Events.json"); }
        }

        public void SaveJsonEvents(List<Event> events)
        {
            using (FileStream jsonFileWriter = File.Create(JsonFileName))
            {
                Utf8JsonWriter jsonWriter = new Utf8JsonWriter(jsonFileWriter, new JsonWriterOptions()
                {
                    SkipValidation = false,
                    Indented = true
                });
                JsonSerializer.Serialize<Event[]>(jsonWriter, events.ToArray());
            }
        }
		public IEnumerable<Event> GetJsonEvent()
		{
			if (File.Exists(JsonFileName))
			{
				using (StreamReader jsonFileReader = File.OpenText(JsonFileName))
				{
					try
					{
						var jsonString = jsonFileReader.ReadToEnd();
						if (!string.IsNullOrWhiteSpace(jsonString))
						{
							return JsonSerializer.Deserialize<Event[]>(jsonString);
						}
					}
					catch (JsonException ex)
					{
						// Handle JsonException (e.g., log the error)
						Console.WriteLine($"JsonException: {ex.Message}");
					}
				}
			}
			else
			{
				// Handle case where the file doesn't exist
				Console.WriteLine("JSON file does not exist.");
			}

			// Return an empty collection or handle the error as appropriate for your application
			return Enumerable.Empty<Event>();
		}



	}
}
