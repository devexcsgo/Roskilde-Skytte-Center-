using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Services;

namespace RSC.Pages.Ammunition
{
    public class DeleteProductModel : PageModel
    {
        private IAmmunitionService _productService;

        public DeleteProductModel(IAmmunitionService productService)
        {
            _productService = productService;
        }

        [BindProperty]
        public Models.Product Product { get; set; }


        public IActionResult OnGet(int id)
        {
            Product = _productService.GetProducts(id);
            if (Product == null)
                return RedirectToPage("Ammunition"); //NotFound er ikke defineret endnu
            
            return Page();
        }

        public IActionResult OnPost()
        {
            Models.Product deletedProduct = _productService.DeleteProduct(Product.ProductId);
            if (deletedProduct == null)
                return RedirectToPage("Ammunition"); //NotFound er ikke defineret endnu

            return RedirectToPage("Ammunition");
        }

    }
}

