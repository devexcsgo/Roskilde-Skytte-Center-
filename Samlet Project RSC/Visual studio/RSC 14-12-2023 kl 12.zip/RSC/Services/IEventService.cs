﻿using RSC.Models;

namespace RSC.Services
{
    public interface IEventService
    {
        /// Dette hænger sammen med EventService.cs linje 95 og skal fjernes hvis det andet bliver fjernet  
        List<Event> GetEvents(int? eventId);
        void AddEvent(Event @event);
        void UpdateEvent(Event @event);
        Event GetEvents(int id);
        Event DeleteEvent(int? EventId);
        IEnumerable<Event> NameSearch(string str);
		List<Event> GetEvents();
	}
}
