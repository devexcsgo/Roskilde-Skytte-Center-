using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.FAQ
{
    public class FAQModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
