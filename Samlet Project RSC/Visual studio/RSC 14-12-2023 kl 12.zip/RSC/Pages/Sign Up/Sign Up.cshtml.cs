using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Sign_Up
{
    public class Sign_UpModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
