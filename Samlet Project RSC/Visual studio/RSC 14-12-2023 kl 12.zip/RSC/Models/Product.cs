﻿namespace RSC.Models
{
    public class Product
    {
        public int? Id { get; set; }

        public string? ProductName { get; set; }

        public double? ProductPrice { get; set; }

        public Product() 
        {
        }

        public Product(string Name, double Price) 
        {
            Id = 0;
            ProductName = Name;
            ProductPrice = Price;
        }
    }
}
