﻿using System.ComponentModel.DataAnnotations;

namespace RSC.Models
{
    public class Event
    {
        [Display(Name = "Id")]
        public int? Id { get; set; }

        [Display(Name = "Navn")]
        [Required(ErrorMessage = "Dette felt skal have et navn")]
        public string? Name { get; set; }

        [Display(Name = "Dato")]
        public DateTime Date { get; set; }

        [Display(Name = "Beskrivelse")]
        public string? Description { get; set; }

        [Display(Name = "Lokation")]
        public string? location { get; set; }

        public Event()
        {
        }
        public Event(string name, string description)
        {
            Id = 0;
            Name = name;
            Description = description;
        }

    }
}
