﻿using RSC.Models;
using System.Text.Json;

namespace RSC.Services
{
	public class JsonFileProductService
	{
		public IWebHostEnvironment WebHostEnvironment { get; }

		public JsonFileProductService(IWebHostEnvironment webHostEnvironment)
		{
			WebHostEnvironment = webHostEnvironment;
		}
		private string JsonFileName
		{
			get { return Path.Combine(WebHostEnvironment.WebRootPath, "Data", "Products.json"); }
		}

		public void SaveJsonProducts(List<Product> products)
		{
			using (FileStream jsonFileWriter = File.Create(JsonFileName))
			{
				Utf8JsonWriter jsonWriter = new Utf8JsonWriter(jsonFileWriter, new JsonWriterOptions()
				{
					SkipValidation = false,
					Indented = true
				});
				JsonSerializer.Serialize<Product[]>(jsonWriter, products.ToArray());
			}
		}
        public Product DeleteProduct(int productId)
        {
            var products = GetJsonProduct().ToList();
            var productToBeDeleted = products.FirstOrDefault(p => p.Id == productId);

            if (productToBeDeleted != null)
            {
                products.Remove(productToBeDeleted);
                SaveJsonProducts(products);
            }

            return productToBeDeleted;
        }
        public IEnumerable<Product> GetJsonProduct()
		{
			if (File.Exists(JsonFileName))
			{
				using (StreamReader jsonFileReader = File.OpenText(JsonFileName))
				{
					try
					{
						var jsonString = jsonFileReader.ReadToEnd();
						if (!string.IsNullOrWhiteSpace(jsonString))
						{
							return JsonSerializer.Deserialize<Product[]>(jsonString);
						}
					}
					catch (JsonException ex)
					{
						// Handle JsonException (e.g., log the error)
						Console.WriteLine($"JsonException: {ex.Message}");
					}
				}
			}
			else
			{
				// Handle case where the file doesn't exist
				Console.WriteLine("JSON file does not exist.");
			}

			// Return an empty collection or handle the error as appropriate for your application
			return Enumerable.Empty<Product>();
		}

    }
}
