﻿namespace RSC.Models
{
	
		public static class ProductManager
		{
			public static List<Product> Products { get; } = new List<Product>();
		}
	
}
