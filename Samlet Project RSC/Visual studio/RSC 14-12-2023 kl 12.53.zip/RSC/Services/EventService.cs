﻿using RSC.Models;
using RSC.wwwroot.Services;

namespace RSC.Services
{
    public class EventService : IEventService
    {
        private List<Event> _event;

        private JsonFileEventService JsonFileEventService { get; set; }

        public EventService(JsonFileEventService jsonFileEventService)
        {
            JsonFileEventService = jsonFileEventService;
			// _Events = MockItems.GetMockItems();
			_event = JsonFileEventService.GetJsonEvent().ToList();
        }
        
        public void AddEvent(Event @event) 
        {
			@event.Id = GetNextId();

			_event.Add(@event);
            JsonFileEventService.SaveJsonEvents(_event);
        }

		private int? GetNextId()
		{
			int? maxId = _event.Max(p => p.Id);
			return maxId + 1;
		}

		public Event GetEvents(int id) 
        {
            foreach (Event @event in _event) 
            {
            if (@event.Id == id) 
                    return @event;
            }
            return null;
        }
        public void UpdateEvent(Event @event)
        {
            if (@event != null)
                {
                foreach (Event i in _event)
                {
                    if (i.Id == @event.Id)
                    {
                        i.Name = @event.Name;
                        i.Date = @event.Date;
                        i.Description = @event.Description;
                    }
                }
                JsonFileEventService.SaveJsonEvents(_event);
            }
        }

        public Event DeleteEvent(int? eventId)
        {
            Event eventToBeDeleted = null;
            foreach (Event @event in _event)
                {
                if (@event.Id == eventId)
                    {
                    eventToBeDeleted = @event;
                    break;
                }
            }

            if (eventToBeDeleted != null)
            {
                _event.Remove(eventToBeDeleted);
                JsonFileEventService.SaveJsonEvents(_event);
            }

            return eventToBeDeleted;
        }

        public List<Event> GetEvents() { return _event; }

        public IEnumerable<Event> NameSearch(string str)
        {
            List<Event> nameSearch = new List<Event>();
            foreach (Event @event in _event)
                {
                if (string.IsNullOrEmpty(str) || @event.Name.ToLower().Contains(str.ToLower()))
                    {
                    nameSearch.Add(@event);
                }
            }

            return nameSearch;
        }
        /// Dette er linket til IEventService.cs linje 7 og skal fjernes hvis det andet bliver fjernet 
		public List<Event> GetEvents(int? eventId)
        {
            throw new NotImplementedException();
        }
    }
    }

