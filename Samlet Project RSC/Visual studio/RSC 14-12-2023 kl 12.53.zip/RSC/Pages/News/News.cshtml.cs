using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.News
{
    public class NewsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
