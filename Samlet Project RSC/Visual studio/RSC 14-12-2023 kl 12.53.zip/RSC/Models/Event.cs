﻿namespace RSC.Models
{
    public class Event
    {
        public int? Id { get; set; }

        public string? Name { get; set; }

        public DateTime Date { get; set; }
          
        public string? Description { get; set; }

        public string? location { get; set; }

        public Event()
        {
        }
        public Event(string name, string description)
        {
            Id = 0;
            Name = name;
            Description = description;
        }

    }
}
