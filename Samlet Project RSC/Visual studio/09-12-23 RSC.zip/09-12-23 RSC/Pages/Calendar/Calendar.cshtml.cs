using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Calendar
{
    public class CalendarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
