using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Services;

namespace RSC.Pages.Ammunition
{
    public class AmmunitionModel : PageModel
    {
		private IAmmunitionService _productService;

		public AmmunitionModel(IAmmunitionService productService)
		{
			_productService = productService;
		}
        [BindProperty]
		public List<Models.Product>? Product { get; private set; }
        //public Models.Item Item { get; set; }

        public string SearchString { get; set; }

		public void OnGet()
		{
			Product = _productService.GetProducts();
		}

		public IActionResult OnPostNameSearch()
		{
			Product = _productService.NameSearch(SearchString).ToList();
			return Page();
		}

	}
}
