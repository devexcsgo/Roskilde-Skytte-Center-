using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Models;
using RSC.Services;

namespace RSC.Pages.Calendar
{
    public class CalendarModel : PageModel
    {
		private IEventService _eventService;

		public CalendarModel(IEventService eventService)
		{
			_eventService = eventService;
		}

		public List<Models.Event>? Events { get; private set; }

		[BindProperty]
		public string SearchString { get; set; }

		public void OnGet()
		{
			Events = _eventService.GetEvents();
		}

		public IActionResult OnPostNameSearch()
		{
			Events = _eventService.NameSearch(SearchString).ToList();
			return Page();
		}

	}
}

