﻿namespace RSC.Models
{
    public class Order
    {
    }
}
