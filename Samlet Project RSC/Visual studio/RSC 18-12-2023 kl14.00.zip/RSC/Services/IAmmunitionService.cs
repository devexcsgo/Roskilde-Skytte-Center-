﻿using RSC.Models;

//Hovedansvar for dette afsnit: Silas

namespace RSC.Services
{
	public interface IAmmunitionService
	{
		List<Product> GetProducts(int? productId);
		void AddProduct(Product product);
		void UpdateProduct(Product product);
		Product GetProducts(int id);
		Product DeleteProduct(int? ProductId);
		IEnumerable<Product> NameSearch(string str);
		List<Product>? GetProducts();
	}
}
