﻿using RSC.Models;

//Hovedansvar for dette afsnit: Silas

namespace RSC.Services
{
    public interface IEventService
    {
        List<Event> GetEvents(int? eventId);
        void AddEvent(Event @event);
        void UpdateEvent(Event @event);
        Event GetEvents(int id);
        Event DeleteEvent(int? EventId);
        IEnumerable<Event> NameSearch(string str);
		List<Event> GetEvents();
	}
}
