﻿using RSC.Models;
using RSC.wwwroot.Services;

//Hovedansvar for dette afsnit: Silas

namespace RSC.Services
{
	public class AmmunitionService : IAmmunitionService
	{
		private List<Product> _product;

		private JsonFileProductService JsonFileProductService { get; set; }

		public AmmunitionService(JsonFileProductService jsonFileProductService)
		{
			JsonFileProductService = jsonFileProductService;
			
			_product = JsonFileProductService.GetJsonProduct().ToList();
		}

		public void AddProduct(Product product)
		{
			product.Id = GetNextProductId();

			_product.Add(product);
			JsonFileProductService.SaveJsonProducts(_product);
		}

		private int? GetNextProductId() 
		{
			int? maxProductId = _product.Max(p => p.Id);
			return maxProductId +1;
		}

		public Product GetProducts(int id) 
		{
			foreach (Product product in _product)
			{
				if (product.Id == id)
					return product;
			}
			return null;
		}
		public void UpdateProduct(Product product)
		{
			if (product != null)
			{
				foreach (Product i in _product)
				{
					if (i.Id == product.Id)
					{
						i.ProductName = product.ProductName;
						i.ProductPrice = product.ProductPrice;
					}
				}
				JsonFileProductService.SaveJsonProducts(_product);
			}
		}
		public Product DeleteProduct(int? productId)
		{
			Product productToBeDeleted = null;
			foreach (Product product in _product)
			{
				if (product.Id == productId)
				{
					productToBeDeleted = product;
					break;
				}
			}

			if (productToBeDeleted != null)
			{
				_product.Remove(productToBeDeleted);
				JsonFileProductService.SaveJsonProducts(_product);
			}

			return productToBeDeleted;
		}

		public List<Product> GetProducts() { return _product; }

		public IEnumerable<Product> NameSearch(string str)
		{
			List<Product> nameSearch = new List<Product>();
			foreach (Product product in _product)
			{
				if (string.IsNullOrEmpty(str) || product.ProductName.ToLower().Contains(str.ToLower()))
				{
					nameSearch.Add(product);
				}
			}

			return nameSearch;
		}

		public List<Product> GetProducts(int? productId)
		{
			throw new NotImplementedException();
		}
	}
}
