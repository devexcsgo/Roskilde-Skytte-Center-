﻿namespace RSC.Models

//Hovedansvar for dette afsnit: Silas
{ 
	public static class EventManager
    {
        public static List<Event> Events { get; } = new List<Event>();
    }
}

