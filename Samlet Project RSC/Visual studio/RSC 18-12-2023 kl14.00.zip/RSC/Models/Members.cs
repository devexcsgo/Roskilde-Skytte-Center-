﻿namespace RSC.Models

//Hovedansvar for dette afsnit: Silas
{
	public class Members
    {
        public int MemberId { get; set; }

        public string MemberName { get; set; }

        public string MemberEmail { get; set; }
    }
}
