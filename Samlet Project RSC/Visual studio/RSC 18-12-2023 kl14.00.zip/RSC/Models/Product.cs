﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

//Hovedansvar for dette afsnit: Tan, Silas og Zimon

namespace RSC.Models
{
    public class Product
    {
        [Display(Name = "Id")]
        public int? Id { get; set; }

        [Display(Name = "Navn")]
        [Required(ErrorMessage = "Dette felt skal have et navn")]
        public string? ProductName { get; set; }

        [Display(Name = "Pris")]
        [Required(ErrorMessage = "Der skal angives en pris")]
        public double? ProductPrice { get; set; }

        public Product() 
        {
        }

        public Product(string Name, double Price) 
        {
            Id = 0;
            ProductName = Name;
            ProductPrice = Price;
        }
    }
}
