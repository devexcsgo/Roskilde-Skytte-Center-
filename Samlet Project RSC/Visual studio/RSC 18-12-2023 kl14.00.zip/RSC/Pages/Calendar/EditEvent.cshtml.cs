using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Services;

//Hovedansvar for dette afsnit: Silas

namespace RSC.Pages.Calendar
{
	public class EditEventModel : PageModel
	{
		private IEventService _eventService;

		public EditEventModel(IEventService eventService)
		{
			_eventService = eventService;
		}

		[BindProperty]
		public Models.Event Event { get; set; }

		public IActionResult OnGet(int id)
		{
			Event = _eventService.GetEvents(id);
			if (Event == null)
				return RedirectToPage("/NotFound"); //NotFound er ikke defineret endnu

			return Page();
		}

		public IActionResult OnPost()
		{
			if (!ModelState.IsValid)
			{
				return Page();
			}

			_eventService.UpdateEvent(Event);
			return RedirectToPage("Calendar");
		}
	}
}
