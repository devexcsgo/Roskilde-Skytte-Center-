using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Models;
using RSC.Services;
using static RSC.Services.IEventService;

//Hovedansvar for dette afsnit: Silas

namespace RSC.Pages.Calendar
{
    public class CreateEventModel : PageModel
    {
        private IEventService _eventService;
        public CreateEventModel(IEventService eventService)
        {
            _eventService = eventService;
        }

        [BindProperty]
        public Event Event { get; set; }
        public IActionResult OnGet()
        {
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            _eventService.AddEvent(Event);
            return RedirectToPage("Calendar");
        }
    }
}

