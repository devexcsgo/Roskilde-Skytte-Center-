using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Models;
using RSC.Services;

//Hovedansvar for dette afsnit: Silas, Tan, Zimon

namespace RSC.Pages.Ammunition
{
    public class EditProductModel : PageModel
    {
		private IAmmunitionService _productService;

		public EditProductModel(IAmmunitionService productService)
		{
			_productService = productService;
		}

		[BindProperty]
		public Models.Product Product { get; set; }

		public IActionResult OnGet(int id)
		{
			Product = _productService.GetProducts(id);
			if (Product == null)
				return RedirectToPage("/NotFound"); //NotFound er ikke defineret endnu

			return Page();
		}

		public IActionResult OnPost()
		{
			if (!ModelState.IsValid)
			{
				return Page();
			}

			_productService.UpdateProduct(Product);
			return RedirectToPage("Ammunition");
		}
    }
}
