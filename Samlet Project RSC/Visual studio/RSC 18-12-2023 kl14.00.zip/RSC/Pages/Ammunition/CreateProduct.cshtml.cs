using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RSC.Models;
using RSC.Services;

//Hovedansvar for dette afsnit: Silas, Tan, Zimon

namespace RSC.Pages.Ammunition
{
	public class CreateProductModel : PageModel
	{
		private IAmmunitionService _productService;

		public CreateProductModel(IAmmunitionService productService)
		{
			_productService = productService;
		}

		[BindProperty]
        public Product Product { get; set; }
		public IActionResult OnGet()
		{
			return Page();
		}

		public IActionResult OnPost()
		{
			if (!ModelState.IsValid)
			{
				return Page();
			}
			_productService.AddProduct(Product);
			return RedirectToPage("Ammunition");
		}
	}
}
