using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

//Hovedansvar for dette afsnit: Silas

namespace RSC.Pages.FAQ
{
    public class FAQModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
