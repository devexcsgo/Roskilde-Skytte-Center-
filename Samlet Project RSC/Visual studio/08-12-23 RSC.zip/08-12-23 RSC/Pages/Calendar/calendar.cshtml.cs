using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Calendar
{
    public class calendarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
