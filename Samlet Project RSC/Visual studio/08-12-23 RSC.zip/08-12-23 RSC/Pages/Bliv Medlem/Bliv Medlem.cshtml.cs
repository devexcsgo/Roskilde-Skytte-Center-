using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Bliv_Medlem
{
    public class Bliv_MedlemModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
