using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RSC.Pages.Nyheder
{
    public class AmmunitionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
